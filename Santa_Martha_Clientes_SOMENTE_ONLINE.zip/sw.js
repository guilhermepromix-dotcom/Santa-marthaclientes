const VERSION='2026-09-27-online-only-1';
self.addEventListener('install',event=>self.skipWaiting());
self.addEventListener('activate',event=>event.waitUntil((async()=>{for(const key of await caches.keys())await caches.delete(key);await self.registration.unregister();await self.clients.claim();})()));
self.addEventListener('fetch',event=>event.respondWith(fetch(event.request)));
