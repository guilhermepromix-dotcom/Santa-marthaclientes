// Santa Martha Clientes — versão somente online.
// Este arquivo existe apenas para neutralizar versões antigas do Service Worker.
self.addEventListener('install',()=>self.skipWaiting());
self.addEventListener('activate',event=>event.waitUntil((async()=>{for(const k of await caches.keys())await caches.delete(k);await self.registration.unregister();await self.clients.claim();})()));
self.addEventListener('fetch',()=>{});
